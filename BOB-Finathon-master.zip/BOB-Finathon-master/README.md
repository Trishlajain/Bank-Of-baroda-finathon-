# BOB-Finathon
Bank of baroda final submission Source code


# Facebook Scraper
We used facebook scrapper so that we can get users with specific target like by searching a group and get user id from it
Run by python filename.py

# PHP Code
It's an simple php code used for webhook in dialogflow so that when user enter city in chat we can get bank branches from calling webhook from dialogflow 
Run by simple php webserver apache or others

# ChatBot
It's an script for sending messege on facebook we can message public users from this script and make them aware about our chatbot chatbot can also target specific group we scrape like we did in facebook scrapper if facebook scraper scrape for startupindia page we can get various public users they also have some startup or idea so we can message them our specific product for startups.
